import React from 'react';

function OrderDetail() {
    return (
        <div>
            <h1>Order Detail</h1>
        </div>
    )
}

export default OrderDetail
